
var config_unit_size = 10;
var config_map_width = 50;
var config_map_height = 50;
